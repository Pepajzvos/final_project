import java.util.Random;
public class Kostka {

private int steny;
private int hod;
public int getSteny() {
	return steny;
}

public void setSteny(int steny) {
	this.steny = steny;
}

public void hod() {
	System.out.println("Hodil jste: " + dv);
}
	Random r = new Random();
	int dv = r.nextInt(getSteny())+1;
	
	
	
	
	
	
	
	
	
	
	
	
	
}
