
public class Potravina {

	private String nazev;
	private int cena;
	
	public Potravina(String n, int c) {
		this.nazev = n;
		this.cena = c;
	}

	public String getNazev() {
		return nazev;
	}

	public void setNazev(String nazev) {
		this.nazev = nazev;
	}

	public int getCena() {
		return cena;
	}

	public void setCena(int cena) {
		this.cena = cena;
	}
	
	
	
	
	
	
	
}
